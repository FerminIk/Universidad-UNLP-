package ejercicio4.figurasycuerpos;


public interface Figura {
    
    public double getArea();
    public double getPerimetro();
        
}
