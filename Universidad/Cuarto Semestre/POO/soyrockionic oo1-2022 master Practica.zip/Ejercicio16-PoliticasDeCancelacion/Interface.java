package ejercicio15.alquilerdepropiedades;

import java.time.LocalDate;

public interface Interface {
   
    public double calcularReembolso(Reserva reserva, LocalDate fecha);
    
}
