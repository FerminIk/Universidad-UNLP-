package ejercicio11.elinversor;

public interface Inversion {
    
    public double valorActual();
            
    
}
